# TrashOut

#### Useful links:
  - PostgreSQL for Windows: https://www.postgresql.org/download/windows/
  - Redis for Windows: https://github.com/rgl/redis/downloads
