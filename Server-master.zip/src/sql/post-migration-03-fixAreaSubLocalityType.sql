UPDATE area SET type = 'subLocality' WHERE type = 'sublocality';
