UPDATE public.user SET last_name = NULL WHERE last_name = '';
UPDATE public.user SET first_name = NULL WHERE first_name = '';

UPDATE public.user SET last_name = NULL WHERE last_name = ' ';
UPDATE public.user SET first_name = NULL WHERE first_name = ' ';


UPDATE public.user SET last_name = NULL WHERE last_name = '  ';
UPDATE public.user SET first_name = NULL WHERE first_name = '  ';
